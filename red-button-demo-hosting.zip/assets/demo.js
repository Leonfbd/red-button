(() => {
  'use strict';

  const stage = document.getElementById('demoStage');
  const progressItems = Array.from(document.querySelectorAll('[data-progress]'));
  const scenarioButtons = Array.from(document.querySelectorAll('[data-scenario]'));
  if (!stage || !progressItems.length || !scenarioButtons.length) return;

  // This state exists only in this browser tab. It is not stored or transmitted.
  const state = { step: 1, scenario: 'managed' };

  const copy = {
    managed: {
      label: 'SCENARIUSZ ZARZĄDZANY · WYNIK PRZYKŁADOWY',
      title: 'Możliwa próba natywnego resetu',
      text: 'W tym przykładzie zakładamy, że urządzenie służbowe ma wymagane uprawnienia, a pozostałe kontrole przechodzą. Prawdziwa aplikacja mogłaby poprosić Androida o wykonanie jednorazowego resetu. Android nadal może odmówić, a przyjęcie żądania nie potwierdza zakończenia resetu.',
      blocked: false
    },
    personal: {
      label: 'SCENARIUSZ PRYWATNY · BRAK UPRAWNIONEJ ŚCIEŻKI',
      title: 'Red Button odmówiłby działania',
      text: 'W tym przykładzie zwykły, niezarządzany telefon nie ma wymaganych uprawnień administratora. Prawdziwa aplikacja powinna w takiej sytuacji odmówić i nie wysyłać żądania resetu.',
      blocked: true
    }
  };

  function updateProgress() {
    progressItems.forEach((item) => {
      const number = Number(item.dataset.progress);
      item.classList.toggle('is-current', number === state.step);
      item.classList.toggle('is-complete', number < state.step);
      if (number === state.step) item.setAttribute('aria-current', 'step');
      else item.removeAttribute('aria-current');
    });
  }

  function updateScenarioButtons() {
    scenarioButtons.forEach((button) => {
      const selected = button.dataset.scenario === state.scenario;
      button.classList.toggle('is-selected', selected);
      button.setAttribute('aria-pressed', String(selected));
    });
  }

  function render() {
    updateProgress();
    updateScenarioButtons();

    if (state.step === 1) {
      stage.innerHTML = `
        <div class="stage-kicker"><span class="stage-number">01</span> PIERWSZE URUCHOMIENIE</div>
        <h3>Najpierw świadoma decyzja.</h3>
        <div class="demo-note demo-note-warm"><span class="note-mark" aria-hidden="true">!</span><p><strong>Pierwsze uruchomienie nie kasuje danych.</strong><br>To moment na zapoznanie się z konsekwencjami.</p></div>
        <div class="consent-list">
          <label class="consent-row"><input type="checkbox" data-consent><span class="custom-check" aria-hidden="true"></span><span>Rozumiem, że po uzbrojeniu kolejne otwarcie aplikacji może automatycznie rozpocząć próbę resetu.</span></label>
          <label class="consent-row"><input type="checkbox" data-consent><span class="custom-check" aria-hidden="true"></span><span>Rozumiem, że reset może bezpowrotnie usunąć dane, może zostać odrzucony i nie jest gwarantowany.</span></label>
        </div>
        <div class="stage-actions"><button class="button button-primary stage-button" type="button" data-action="arm" disabled>Potwierdź zgodę <span aria-hidden="true">→</span></button></div>
        <p class="stage-footnote">Zaznaczenia służą wyłącznie do przejścia przez pokaz. Nic nie jest zapisywane.</p>
      `;
      const consentBoxes = Array.from(stage.querySelectorAll('[data-consent]'));
      const armButton = stage.querySelector('[data-action="arm"]');
      const syncButton = () => { armButton.disabled = !consentBoxes.every((box) => box.checked); };
      consentBoxes.forEach((box) => box.addEventListener('change', syncButton));
      armButton.addEventListener('click', () => {
        state.step = 2;
        render();
      });
      return;
    }

    if (state.step === 2) {
      stage.innerHTML = `
        <div class="stage-kicker"><span class="stage-number">02</span> ZGODA W DEMONSTRACJI</div>
        <h3>Zgoda pokazowa została zaznaczona.</h3>
        <div class="demo-note demo-note-warm"><span class="note-mark" aria-hidden="true">✓</span><p><strong>W prawdziwej aplikacji pierwszy start kończy się bez resetu.</strong><br>Upoważnienie dotyczy jednej próby przy kolejnym otwarciu.</p></div>
        <p class="result-copy">W tej stronie zgoda istnieje wyłącznie w pamięci bieżącej karty przeglądarki. Nie jest zapisywana ani wysyłana. Przycisk poniżej tylko pokazuje przykładowy następny krok.</p>
        <div class="stage-actions"><button class="button button-primary stage-button" type="button" data-action="next">Pokaż symulację kolejnego otwarcia <span aria-hidden="true">→</span></button></div>
        <p class="stage-footnote">W aplikacji następne otwarcie może rozpocząć próbę bez dodatkowego potwierdzenia w aplikacji.</p>
      `;
      stage.querySelector('[data-action="next"]').addEventListener('click', () => {
        state.step = 3;
        render();
      });
      return;
    }

    const result = copy[state.scenario];
    const labelClass = result.blocked ? 'result-label is-blocked' : 'result-label';
    stage.innerHTML = `
      <div class="stage-kicker"><span class="stage-number">03</span> WYNIK PRZYKŁADOWY</div>
      <span class="${labelClass}">${result.label}</span>
      <h3>${result.title}</h3>
      <p class="result-copy">${result.text}</p>
      <div class="result-notice"><span class="result-notice-icon" aria-hidden="true">!</span><span>To wyłącznie pokaz. Ta strona nie sprawdziła telefonu i nie wysłała żadnego polecenia do Androida.</span></div>
      <div class="stage-actions-wrap"><button class="button-outline" type="button" data-action="restart">Powtórz prezentację</button><button class="button-outline" type="button" data-action="change">Zmień scenariusz</button></div>
    `;
    stage.querySelector('[data-action="restart"]').addEventListener('click', () => {
      state.step = 1;
      render();
    });
    stage.querySelector('[data-action="change"]').addEventListener('click', () => {
      state.scenario = state.scenario === 'managed' ? 'personal' : 'managed';
      state.step = 3;
      render();
    });
  }

  scenarioButtons.forEach((button) => {
    button.addEventListener('click', () => {
      state.scenario = button.dataset.scenario;
      render();
    });
  });

  render();
})();
